document.addEventListener('scroll',()=>{
    if(window.scrollY > 5){
        document.querySelector('.nav').classList.add('scroll')
        document.querySelector('.menuitems2').classList.remove('click')
    }
    else{
        document.querySelector('.nav').classList.remove('scroll')
    }
})

document.querySelector('.hamburger').addEventListener('click',()=>{
    document.querySelector('.menuitems2').classList.toggle('click')
    console.log('click')
})